SkillForge AI starter files

Lesson: Notebook workflow
Course: AI & Machine Learning Masterclass

1. Extract this folder
2. Open the included README and start file
3. Follow along with the lesson video
