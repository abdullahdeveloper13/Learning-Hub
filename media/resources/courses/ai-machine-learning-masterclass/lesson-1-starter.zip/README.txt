SkillForge AI starter files

Lesson: What AI systems can and cannot do
Course: AI & Machine Learning Masterclass

1. Extract this folder
2. Open the included README and start file
3. Follow along with the lesson video
