SkillForge AI starter files

Lesson: Packaging reusable code
Course: Python Programming from Beginner to Advanced

1. Extract this folder
2. Open the included README and start file
3. Follow along with the lesson video
