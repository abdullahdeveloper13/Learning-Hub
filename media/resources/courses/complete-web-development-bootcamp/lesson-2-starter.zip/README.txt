SkillForge AI starter files

Lesson: Responsive layouts with Flexbox and Grid
Course: Complete Web Development Bootcamp

1. Extract this folder
2. Open the included README and start file
3. Follow along with the lesson video
