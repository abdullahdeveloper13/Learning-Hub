SkillForge AI starter files

Lesson: API handlers and mutations
Course: Complete Web Development Bootcamp

1. Extract this folder
2. Open the included README and start file
3. Follow along with the lesson video
